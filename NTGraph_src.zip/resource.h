//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NTGraph.rc
//
#define IDS_NTGRAPH                     1
#define IDD_ABOUTBOX_NTGRAPH            1
#define IDB_NTGRAPH                     1
#define IDI_ABOUTDLL                    1
#define IDS_NTGRAPH_PPG                 2
#define IDD_PROPPAGE_ELEMENTS           106
#define IDS_NTGRAPH_PPG_CAPTION         200
#define IDD_PROPPAGE_NTGRAPH            200
#define IDC_ELEMENTLIST                 201
#define IDC_CHECK_SHOWGRID              201
#define IDS_ELEMENTS_PPG                202
#define IDC_CAPTION                     202
#define IDC_EDIT_NAME                   202
#define IDC_CHECK_VISIBLE               203
#define IDS_ELEMENTS_PPG_CAPTION        203
#define IDC_CHECK_SCOPE                 203
#define IDC_CHECK_SOLID                 204
#define IDC_CHECK_XLOG                  204
#define IDC_EDIT_X                      204
#define IDS_ANNOTATION_PPG              204
#define IDC_CHECK_YLOG                  205
#define IDC_EDIT_Y                      205
#define IDS_ANNOTATION_PPG_CAPTION      205
#define IDC_ADDBUTTON                   206
#define IDC_GRID_COLOR                  206
#define IDS_CURSOR_PPG                  206
#define IDC_DELBUTTON                   207
#define IDC_FRAME_COLOR                 207
#define IDS_CURSOR_PPG_CAPTION          207
#define IDC_POINT_COLOR                 208
#define IDC_PLOT_COLOR                  208
#define IDS_FORMAT_PPG                  208
#define IDC_AXIS_COLOR                  209
#define IDS_FORMAT_PPG_CAPTION          209
#define IDC_COMBO_TYPE                  210
#define IDC_LABEL_COLOR                 210
#define IDC_SPIN_WIDTH                  211
#define IDC_CURSOR_COLOR                211
#define IDC_LABEL_BGCOLOR               211
#define IDC_COMBO_SYMBOL                212
#define IDC_EDIT_WIDTH                  213
#define IDC_COMBO_STYLE                 213
#define IDC_LINE_COLOR                  214
#define IDC_COMBO_MODE                  214
#define IDB_BITMAP1                     214
#define IDC_COMBO_SNAP                  214
#define IDB_BITMAP2                     215
#define IDC_COMBO_FRAME                 215
#define IDC_CURSORS                     215
#define IDB_BITMAP3                     216
#define IDC_COMBO_ORIENTATION           216
#define IDC_COMBO_AXIS                  216
#define IDC_EDIT_CAPTION                217
#define IDB_BITMAP4                     218
#define IDC_LABELS                      218
#define IDC_ANNOTATIONS                 218
#define IDC_EDIT_FORMAT                 218
#define IDB_FRAME                       221
#define IDC_FORMAT_LIST                 221
#define IDC_BUTTON_DEFAULT              222
#define IDB_MARG                        228
#define IDD_PROPPAGE_ANNOTATION         230
#define IDD_PROPPAGE_CURSOR             232
#define IDD_PROPAGE_FORMAT              234

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        236
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         223
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
