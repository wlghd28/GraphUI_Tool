//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_PROPERTIES                  1003
#define IDC_NUMTRACESSLIDE              1005
#define IDC_PTSPERTRACESLIDE            1006
#define IDC_STACKEDBOOLEAN              1007
#define IDC_BUTTON_DEMO                 1013
#define IDC_BUTTON_DEMOS                1014
#define IDC_NTGRAPHCTRL1                1019
#define IDC_NTGRAPHCTRL2                1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
