
// graDlg.h : ��� ����
//

#pragma once
#include "graph1.h"

class CGraphData
{
public:
	CGraphData(void){};
    CGraphData(CGraph1* g, unsigned char id, unsigned long lcolor, float xs, unsigned int max)
    {
        m_graph = g;
        scroll = false;
        eID = id;
        lineColor = lcolor;
        x = 0.f;
        xstep = xs;
        count = 0;
        MAX = max;
        y = new float[MAX];
        for ( int i = 0 ; i < MAX ; i ++ )
        {
            y[i] = 0.f;
        }
    }
	~CGraphData(void){delete []y;};
 
    CGraph1* m_graph;
    bool scroll;
    unsigned char eID;
    unsigned long lineColor;
    float x;
    float xstep;
    float* y;
    unsigned int count;
    unsigned int MAX;
};

// CgraDlg ��ȭ ����
class CgraDlg : public CDialogEx
{
// �����Դϴ�.
public:
	CgraDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_GRA_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CGraph1 m_graph1;
	void m_AddPoint(CGraph1* graph, unsigned char eID, unsigned long lineColor, float* x, float xstep, float* y, float yvalue, bool* scroll, unsigned int* count, unsigned int MAX);
	CGraphData* m_gd1;
	void m_AddPoint(CGraphData* gd, float yvalue);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
